// content.js
// نمایش نوار بالایی هنگام بلاک شدن (نام پیام‌ها: show_bar, server_result, allow_and_reload)

(function(){
  let blocked = false;
  let currentUrl = null;
  let barRoot = null;
  let overlay = null;

  // inject styles (one-time)
  function injectStyle() {
    if (document.getElementById('phishguard-style')) return;
    const s = document.createElement('style');
    s.id = 'phishguard-style';
    s.textContent = `
      .pg-wrapper { position: fixed; left:0; right:0; top:0; z-index:2147483647; font-family: Inter, system-ui, sans-serif; pointer-events:auto; }
      .pg-bar { display:flex; justify-content:space-between; align-items:center; padding:10px 14px; gap:12px;
        backdrop-filter: blur(6px); background: linear-gradient(90deg, rgba(8,15,32,0.96), rgba(12,20,40,0.90));
        color: #fff; box-shadow: 0 8px 30px rgba(2,6,23,0.6); border-bottom-left-radius:10px; border-bottom-right-radius:10px;
      }
      .pg-left { display:flex; align-items:center; gap:12px; }
      .pg-logo { width:42px; height:42px; border-radius:8px; object-fit:cover; }
      .pg-title { font-weight:700; font-size:16px; }
      .pg-sub { font-size:12px; opacity:0.95; margin-top:2px; max-width:60vw; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .pg-actions { display:flex; gap:8px; align-items:center; }
      .pg-btn { padding:8px 10px; border-radius:9px; border:none; cursor:pointer; font-weight:700; background: rgba(255,255,255,0.06); color:#e6eef8; }
      .pg-btn-danger { background: linear-gradient(90deg, rgba(255,60,80,0.16), rgba(255,60,80,0.10)); }
      .pg-btn-success { background: linear-gradient(90deg, rgba(34,197,94,0.12), rgba(34,197,94,0.06)); color:#dfffe6; }
      body.phishguard-blocked { overflow: hidden !important; }
      .pg-overlay { position: fixed; left:0; right:0; top:64px; bottom:0; z-index:2147483646; background: linear-gradient(180deg, rgba(0,0,0,0.02), rgba(0,0,0,0.35)); backdrop-filter: blur(2px); }
      @media (max-width:420px) { .pg-actions { flex-direction:column-reverse; gap:6px; } .pg-sub{max-width:40vw} }
    `;
    document.documentElement.appendChild(s);
  }

  function createBar(url) {
    injectStyle();
    if (barRoot) return barRoot;

    barRoot = document.createElement('div');
    barRoot.id = 'phishguard-bar-root';
    barRoot.innerHTML = `
      <div class="pg-wrapper">
        <div class="pg-bar">
          <div class="pg-left">
            <img class="pg-logo" src="${chrome.runtime.getURL('icons/icon48.png')}" />
            <div>
              <div class="pg-title">PhishGuard</div>
              <div class="pg-sub" id="pg-sub">در حال بررسی آدرس...</div>
            </div>
          </div>
          <div class="pg-actions">
            <button id="pg-open-anyway" class="pg-btn pg-btn-danger">باز کردن با مسئولیت خود</button>
            <button id="pg-add-trusted" class="pg-btn pg-btn-success">افزودن به ایمن‌ها</button>
            <button id="pg-close-tab" class="pg-btn">بستن تب</button>
          </div>
        </div>
      </div>
    `;
    document.documentElement.appendChild(barRoot);

    // overlay
    overlay = document.createElement('div');
    overlay.className = 'pg-overlay';
    document.documentElement.appendChild(overlay);

    // handlers
    const btnOpen = document.getElementById('pg-open-anyway');
    const btnTrusted = document.getElementById('pg-add-trusted');
    const btnClose = document.getElementById('pg-close-tab');

    btnOpen.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'open_anyway', url, tabId: null }, () => {});
      removeBar();
    });

    btnTrusted.addEventListener('click', () => {
      try {
        const domain = (new URL(url)).hostname;
        setSubText('در حال افزودن به ایمن‌ها...');
        chrome.runtime.sendMessage({ action: 'add_trusted', domain, url, tabId: null }, (resp) => {
          setSubText('به ایمن‌ها اضافه شد — در حال باز کردن صفحه...');
          setTimeout(() => removeBar(), 800);
        });
      } catch (e) {
        setSubText('خطا در استخراج دامنه.');
      }
    });

    btnClose.addEventListener('click', () => {
      try { window.close(); } catch(e){ /* ignore */ }
      removeBar();
    });

    return barRoot;
  }

  function setSubText(t) {
    const el = document.getElementById('pg-sub');
    if (el) el.textContent = t;
  }

  function showBar(url) {
    if (blocked) return;
    blocked = true;
    currentUrl = url;
    createBar(url);
    document.body.classList.add('phishguard-blocked');
  }

  function updateResult(result) {
    if (!blocked) return;
    if (!result) {
      setSubText('خطا در اتصال به سرور — می‌توانید با مسئولیت خود باز کنید.');
      return;
    }
    if (result.error) {
      setSubText('خطا: ' + result.error + ' — می‌توانید با مسئولیت خود باز کنید.');
      return;
    }
    if (result.is_phishing) {
      const reasons = (result.reasons || []).slice(0,3).join(' · ');
      setSubText(`احتمال فیشینگ: ${result.probability}% — ${reasons}`);
      // منتظر تصمیم کاربر می‌مونیم
    } else {
      setSubText('سایت ایمن است — در حال باز شدن خودکار...');
      setTimeout(() => {
        removeBar();
        try { location.reload(true); } catch(e) { location.href = currentUrl; }
      }, 800);
    }
  }

  function allowAndReload() {
    removeBar();
    try { location.reload(true); } catch(e) { location.href = currentUrl; }
  }

  function removeBar() {
    if (!blocked) return;
    blocked = false;
    currentUrl = null;
    if (barRoot) { barRoot.remove(); barRoot = null; }
    if (overlay) { overlay.remove(); overlay = null; }
    document.body.classList.remove('phishguard-blocked');
  }

  // گوش دادن به پیام‌های background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'show_bar') {
      try { showBar(msg.url); } catch(e) { console.warn(e); }
    }
    if (msg.action === 'server_result') {
      updateResult(msg.result);
    }
    if (msg.action === 'allow_and_reload') {
      allowAndReload();
    }
  });

})();
