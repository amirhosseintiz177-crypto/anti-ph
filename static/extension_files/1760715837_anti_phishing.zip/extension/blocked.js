// blocked.js (نسخه اصلاح شده برای استفاده از background.js)
// این صفحه پارامتر ?u=BASE64(URL) را می‌گیرد، از background می‌خواهد به سرور بزند و نتیجه را نشان می‌دهد.

function getParamU() {
    const qs = new URLSearchParams(location.search);
    const u = qs.get('u');
    if (!u) return null;
    try {
        return decodeURIComponent(escape(atob(u)));
    } catch (e) {
        return null;
    }
}

const siteTitle = document.getElementById('site-title');
const siteSub = document.getElementById('site-sub');
const spinner = document.getElementById('spinner');
const resultArea = document.getElementById('result-area');
const resultText = document.getElementById('result-text');
const btnOpen = document.getElementById('open-anyway');
const btnTrusted = document.getElementById('add-trusted');
const btnClose = document.getElementById('close-tab');

// متغیرهای SERVER و ADD_TRUSTED دیگر در اینجا استفاده نمی‌شوند چون کار را به background می‌سپاریم.

(async function init() {
    const original = getParamU();
    if (!original) {
        siteTitle.textContent = 'آدرس نامعتبر';
        siteSub.textContent = 'هیچ آدرس مقصدی یافت نشد.';
        spinner.style.display = 'none';
        setupButtons(null); // غیرفعال کردن دکمه‌ها
        return;
    }

    // URL را فقط دامین نشان بدهیم تا خواناتر باشد
    let displayUrl = original;
    try {
        const urlObj = new URL(original);
        displayUrl = urlObj.hostname;
    } catch (e) { /* ignore */ }
    
    siteTitle.textContent = displayUrl;
    siteSub.textContent = 'در حال بررسی توسط سرور محلی...';
    resultArea.hidden = true;
    spinner.style.display = 'block';

    // **تغییر اصلی:** ارسال پیام به background برای انجام بررسی
    // background خودش sensitivity را از storage می‌خواند.
    let result = null;
    try {
        // از background می‌خواهیم بررسی را انجام دهد و نتیجه را برگرداند.
        result = await new Promise(res => {
            chrome.runtime.sendMessage({ action: 'check_now', url: original }, (r) => {
                // اگر پاسخ موفقیت‌آمیز باشد، نتیجه داخل r.result است.
                res(r && r.result ? r.result : { is_phishing: false, error: 'no_response' });
            });
        });
    } catch (e) {
        // خطای ارتباط با Service Worker
        result = { is_phishing: false, error: 'service_worker_comms_error' };
    }

    // نمایش نتیجه
    spinner.style.display = 'none';
    resultArea.hidden = false;

    if (result.error) {
        // برای این خطاها، دکمه‌ها باید فعال باشند
        resultText.innerHTML = `خطا در بررسی: ${result.error} — می‌توانید با مسئولیت خود ادامه دهید.`;
        setupButtons(original);
        return;
    }

    if (result.is_phishing === true) {
        // فیشینگ تشخیص داده شده
        const reasons = (result.reasons || []).slice(0, 5).join(' · ');
        resultText.innerHTML = `<span style="color:#ffb3b3">ممکن است فیشینگ باشد (${result.probability}%)</span><br/>دلایل: ${reasons}`;
        setupButtons(original); // دکمه‌ها را برای تصمیم کاربر فعال کن
    } else {
        // ایمن است — باید توسط background باز شود.
        resultText.innerHTML = `<span style="color:#bfffe0">سایت ایمن است — در حال باز شدن...</span>`;
        // background.js قبلاً در پاسخ به 'check_now' تب را باز کرده است (به شرط موفقیت).
        // اگر این کد اجرا شود یعنی background تب را باز کرده و ما باید صبر کنیم. 
        // در واقع در ساختار جدید، نیازی به setTimeout و open_anyway دوباره نیست.
        // اما چون sendMessage یک promise نیست و ممکن است کد در background.js زودتر از این قسمت اجرا شود،
        // بهتر است یک بار دیگر پیام باز شدن را بفرستیم.

        // اگر از ساختار بالا استفاده کنیم، background.js *قبل از* sendResponse اقدام به باز کردن تب می‌کند. 
        // بنابراین در این حالت، این بخش از کد *هرگز* به دلیل باز شدن تب اجرا نمی‌شود! 
        // باید در background.js بعد از sendResponse، باز کردن تب را انجام دهیم، یا از open_anyway استفاده کنیم.
        
        // **تصمیم نهایی:** اجازه می‌دهیم background.js مسئول باز کردن باشد (بعد از ارسال پاسخ)
        // این حالت فقط برای زمانی که fetch در blocked.js بود خوب بود. در حالت جدید، چون background خودش بررسی را انجام داده،
        // اگر ایمن باشد، باید تب را باز کند و این صفحه دیگر نباید دیده شود یا باید بسته شود.

        // **بهترین حالت:** از آنجایی که در `background.js` تب را بعد از sendResponse باز نمی‌کنیم
        // (به دلیل جلوگیری از race condition و کنترل بیشتر)، باید از 'open_anyway' استفاده کنیم:
        setTimeout(() => {
             chrome.runtime.sendMessage({ action: 'open_anyway', url: original }, () => {
                 // nothing
             });
        }, 700);
    }
})();

function setupButtons(original) {
    // اگر original === null باشد، دکمه‌ها غیرفعال شوند
    if (!original) {
        btnOpen.disabled = true;
        btnTrusted.disabled = true;
        btnClose.disabled = true;
        return;
    }

    btnOpen.disabled = false;
    btnTrusted.disabled = false;
    btnClose.disabled = false;

    btnOpen.onclick = () => {
        chrome.runtime.sendMessage({ action: 'open_anyway', url: original }, (r) => {
            // nothing
        });
    };
    btnTrusted.onclick = async () => {
        // دامین را استخراج و به background برای add_trusted بزن
        try {
            const domain = (new URL(original)).hostname;
            chrome.runtime.sendMessage({ action: 'add_trusted', domain, url: original }, (r) => {
                // ممکن است موفق شود سپس تب باز شود
            });
        } catch (e) {
            console.error(e);
        }
    };
    btnClose.onclick = () => {
        // درخواست بستن تب به background
        chrome.runtime.sendMessage({ action: 'close_tab' }, () => {
            if (window.close) window.close(); // تلاش نهایی برای بستن خودکار
        });
    };
}