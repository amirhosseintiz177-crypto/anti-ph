// popup.js
// مدیریت تنظیمات و تاریخچه برای popup
document.addEventListener('DOMContentLoaded', () => {

  const elEnabled = document.getElementById('enabled');
  const elSensitivity = document.getElementById('sensitivity');
  const elSensitivityVal = document.getElementById('sensitivity-val');
  const elHistory = document.getElementById('history');
  const elClearHistory = document.getElementById('clear-history');
  const elOpenAdmin = document.getElementById('open-admin');
  const elRefresh = document.getElementById('refresh');

  // درخواست تنظیمات از background
  chrome.runtime.sendMessage({ action: 'get_settings' }, (settings) => {
    // defaults if undefined
    const enabled = (settings && typeof settings.enabled !== 'undefined') ? settings.enabled : true;
    const sensitivity = (settings && typeof settings.sensitivity !== 'undefined') ? settings.sensitivity : 75;
    const history = (settings && settings.history) ? settings.history : [];

    elEnabled.checked = enabled;
    elSensitivity.value = sensitivity;
    elSensitivityVal.textContent = sensitivity;
    renderHistory(history);
  });

  // تغییر وضعیت روشن/خاموش
  elEnabled.addEventListener('change', () => {
    const v = elEnabled.checked;
    chrome.runtime.sendMessage({ action: 'set_settings', settings: { enabled: v } }, (resp) => {
      // optionally show tiny feedback
      elEnabled.disabled = true;
      setTimeout(() => elEnabled.disabled = false, 300);
    });
  });

  // اسلایدر حساسیت
  elSensitivity.addEventListener('input', () => {
    elSensitivityVal.textContent = elSensitivity.value;
  });
  elSensitivity.addEventListener('change', () => {
    const v = parseInt(elSensitivity.value, 10);
    chrome.runtime.sendMessage({ action: 'set_settings', settings: { sensitivity: v } }, (resp) => {
      elSensitivity.disabled = true;
      setTimeout(() => elSensitivity.disabled = false, 300);
    });
  });

  // پاک کردن تاریخچه
  elClearHistory.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'set_settings', settings: { history: [] } }, (resp) => {
      renderHistory([]);
    });
  });

  // باز کردن پنل ادمین روی لوکال
  elOpenAdmin.addEventListener('click', () => {
    chrome.tabs.create({ url: 'http://127.0.0.1:8000/admin' });
  });

  // رفرش تاریخچه/تنظیمات
  elRefresh.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'get_settings' }, (settings) => {
      const history = (settings && settings.history) ? settings.history : [];
      renderHistory(history);
    });
  });

  // رندر تاریخچه در popup
  function renderHistory(items) {
    elHistory.innerHTML = '';
    if (!items || items.length === 0) {
      elHistory.innerHTML = '<div class="empty">تاریخچه‌ای وجود ندارد.</div>';
      return;
    }
    const list = document.createElement('div');
    list.className = 'hist-list';
    // نمایش حداکثر 12 مورد اخیر
    items.slice(0, 12).forEach(it => {
      const d = document.createElement('div');
      d.className = 'hist-item';

      const shortUrl = it.url && it.url.length > 60 ? it.url.slice(0, 60) + '…' : (it.url || '');
      const timeStr = it.time ? (() => {
        try { return new Date(it.time).toLocaleString(); } catch(e) { return it.time; }
        })() : '';

      let resultText = 'نامعلوم';
      if (it.result && it.result.is_phishing === true) {
        resultText = `فیشینگ ${it.result.probability ?? ''}%`;
      } else if (it.result && it.result.error) {
        resultText = `خطا: ${it.result.error}`;
      } else {
        resultText = 'ایمن';
      }

      d.innerHTML = `
        <div class="u">${escapeHtml(shortUrl)}</div>
        <div class="r">${escapeHtml(resultText)}</div>
        <div class="t">${escapeHtml(timeStr)}</div>
      `;
      list.appendChild(d);
    });
    elHistory.appendChild(list);
  }

  // ساده سازی برای امنیت نمایش متن
  function escapeHtml(s) {
    if (!s) return '';
    return s.replace(/[&<>"'`]/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;','`':'&#96;'}[m]));
  }

});
