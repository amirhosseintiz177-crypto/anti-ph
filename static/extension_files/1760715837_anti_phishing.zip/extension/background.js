// background.js (نسخه اصلاح شده برای جلوگیری از حلقه)
// مدیریت رویداد webNavigation و نگهداری موقتی تب‌ها تا زمان پاسخ سرور

const SERVER_CHECK = "http://127.0.0.1:8000/check_link";
const SERVER_ADD_TRUSTED = "http://127.0.0.1:8000/add_trusted";

const DEFAULTS = {
    enabled: true,
    sensitivity: 75,
    history: []
};

// نگهداری mapping از tabId -> { url: originalUrl, status: 'PENDING' | 'ALLOW_NEXT' }
const pendingTabs = new Map();
const STATUS_PENDING = 'PENDING';
const STATUS_ALLOW_NEXT = 'ALLOW_NEXT'; // برای سیگنال دهی به onBeforeNavigate که هدایت بعدی را نادیده بگیرد

// کمک‌افزارهای ذخیره‌سازی
function getSettings() {
    return new Promise(res => chrome.storage.local.get(DEFAULTS, obj => res(obj)));
}
function setSettings(obj) {
    return new Promise(res => chrome.storage.local.set(obj, () => res()));
}
async function addHistory(entry) {
    const s = await getSettings();
    const h = s.history || [];
    h.unshift(entry);
    if (h.length > 300) h.pop();
    await setSettings({ history: h });
}

// وقتی افزونه نصب شد، تنظیمات اولیه را قرار بده
chrome.runtime.onInstalled.addListener(async () => {
    const s = await getSettings();
    console.log("PhishGuard installed, settings:", s);
});

// شنیدن رویداد navigation پیش از شروع (main_frame)
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
    try {
        // فقط main_frame و فقط در تب‌ها (frameId === 0)
        if (details.frameId !== 0) return;
        const tabId = details.tabId;
        const url = details.url;

        // اگر این تب در حالت 'ALLOW_NEXT' است (یعنی خودمان داریم بازش می‌کنیم)
        const pendingState = pendingTabs.get(tabId);
        if (pendingState && pendingState.status === STATUS_ALLOW_NEXT) {
            // اجازه بده برود و حالت موقت را حذف کن
            pendingTabs.delete(tabId);
            console.log("Navigation allowed (self-initiated):", url);
            return;
        }

        // نذاریم صفحه‌های داخلی افزونه یا chrome:// یا فایل extension دوباره هدایت بشه
        if (url.startsWith(chrome.runtime.getURL(""))) return;
        if (url.startsWith("chrome://") || url.startsWith("about:") || url.startsWith("edge://")) return;

        const settings = await getSettings();
        if (!settings.enabled) return;

        // اگر همین تب در حالت PENDING است، نکنیم دوباره کاری
        if (pendingState && pendingState.status === STATUS_PENDING) return;
        
        // اگر این URL همان URLای بود که در blocked.html است، نباید دوباره بلاک شود (این مورد برای اطمینان بیشتر است، اگرچه شرط بالا نیز باید کار کند)
        if (url.startsWith(chrome.runtime.getURL("blocked.html"))) return;


        // علامت‌گذاری که این تب در حالت بررسی است
        pendingTabs.set(tabId, { url, status: STATUS_PENDING, time: Date.now() });

        // رمزگذاری URL برای پاس دادن به صفحه blocked
        const encoded = btoa(unescape(encodeURIComponent(url)));
        const blockedPage = chrome.runtime.getURL(`blocked.html?u=${encoded}`);

        // هدایت تب به صفحهٔ بینابینی افزونه (این باعث می‌شود صفحهٔ مقصد لود نشود تا وقتی تصمیم گرفته شود)
        await chrome.tabs.update(tabId, { url: blockedPage });
        console.log("Redirected tab", tabId, "to interstitial for", url);
    } catch (e) {
        console.error("onBeforeNavigate handler error:", e);
    }
});

// پیام‌هایی که blocked page یا popup می‌فرستند را هندل کن
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
        try {
            if (msg.action === 'check_now') {
                // blocked page درخواست کرد که بررسی را انجام دهد (msg.url)
                const tabId = sender.tab ? sender.tab.id : null;
                const url = msg.url;
                const settings = await getSettings();
                const body = { url, user_sensitivity: settings.sensitivity };

                let result = null;
                try {
                    const resp = await fetch(SERVER_CHECK, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body),
                    });
                    result = resp.ok ? await resp.json() : { is_phishing: false, error: 'server_error' };
                } catch (e) {
                    console.warn("Server check failed:", e);
                    result = { is_phishing: false, error: 'timeout_or_network' };
                }

                // ذخیره تاریخچه
                await addHistory({ url, time: new Date().toISOString(), result });

                // ارسال نتیجه به blocked page (یک reply)
                sendResponse({ ok: true, result });

                // اگر ایمن بود => باز کردن URL واقعی در همان تب
                if (result && result.is_phishing !== true) {
                    if (tabId != null) {
                        // **مهم‌ترین تغییر:** تنظیم وضعیت به ALLOW_NEXT پیش از باز کردن تب
                        // این به onBeforeNavigate می‌گوید که هدایت بعدی به این URL را نادیده بگیرد
                        pendingTabs.set(tabId, { url, status: STATUS_ALLOW_NEXT });
                        
                        await chrome.tabs.update(tabId, { url });
                        console.log("Allowed and opened:", url);
                        // توجه: حذف نهایی از pendingTabs در onBeforeNavigate رخ خواهد داد.
                    }
                } else {
                    // فیشینگ تشخیص داده شد — status PENDING باقی می‌ماند تا کاربر تصمیم بگیرد
                    console.log("Phishing detected:", url, result && result.probability);
                }
                return; // we used sendResponse
            }

            if (msg.action === 'open_anyway') {
                // باز کردن URL با مسئولیت خود کاربر
                const tabId = sender.tab ? sender.tab.id : msg.tabId;
                const url = msg.url;
                if (tabId != null) {
                    // **مهم‌ترین تغییر:** تنظیم وضعیت به ALLOW_NEXT
                    pendingTabs.set(tabId, { url, status: STATUS_ALLOW_NEXT });
                    await chrome.tabs.update(tabId, { url });
                    sendResponse({ ok: true });
                    // حذف نهایی در onBeforeNavigate
                } else {
                    sendResponse({ ok: false });
                }
                return;
            }

            if (msg.action === 'add_trusted') {
                // تماس با سرور برای افزودن به لیست ایمن‌ها
                const domain = msg.domain;
                try {
                    await fetch(SERVER_ADD_TRUSTED, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ site: domain })
                    });
                    // بعد از افزودن، اگر sender تب باشد، بازش کن
                    const tabId = sender.tab ? sender.tab.id : msg.tabId;
                    const url = msg.url;
                    if (tabId != null && url) {
                        // **مهم‌ترین تغییر:** تنظیم وضعیت به ALLOW_NEXT
                        pendingTabs.set(tabId, { url, status: STATUS_ALLOW_NEXT });
                        await chrome.tabs.update(tabId, { url });
                        // حذف نهایی در onBeforeNavigate
                    }
                    sendResponse({ ok: true });
                } catch (e) {
                    console.error("add_trusted failed:", e);
                    sendResponse({ ok: false, err: e.toString() });
                }
                return;
            }

            // ... سایر اکشن‌ها (get_settings, set_settings, get_history, close_tab)
            if (msg.action === 'get_settings') {
                const s = await getSettings();
                sendResponse(s);
                return;
            }

            if (msg.action === 'set_settings') {
                await setSettings(msg.settings || {});
                sendResponse({ ok: true });
                return;
            }

            if (msg.action === 'get_history') {
                const s = await getSettings();
                sendResponse({ history: s.history || [] });
                return;
            }
            
            if (msg.action === 'close_tab') {
                const tabId = sender.tab ? sender.tab.id : msg.tabId;
                if (tabId != null) {
                    // تب را ببند و از pending حذف کن (اگر هست)
                    pendingTabs.delete(tabId);
                    await chrome.tabs.remove(tabId);
                    sendResponse({ ok: true });
                } else {
                    sendResponse({ ok: false, err: 'No tabId' });
                }
                return;
            }


        } catch (e) {
            console.error("onMessage error:", e);
            sendResponse({ ok: false, err: e.toString() });
        }
    })();

    return true; // indicate we'll sendResponse asynchronously
});